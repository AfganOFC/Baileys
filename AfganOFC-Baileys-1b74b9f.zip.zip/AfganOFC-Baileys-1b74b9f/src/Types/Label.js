"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelColor = void 0;
/** WhatsApp has 20 predefined colors */
var LabelColor;
(function (LabelColor) {
    LabelColor[LabelColor["Color1"] = 0] = "Color1";
    LabelColor[LabelColor["Color2"] = 1] = "Color2";
    LabelColor[LabelColor["Color3"] = 2] = "Color3";
    LabelColor[LabelColor["Color4"] = 3] = "Color4";
    LabelColor[LabelColor["Color5"] = 4] = "Color5";
    LabelColor[LabelColor["Color6"] = 5] = "Color6";
    LabelColor[LabelColor["Color7"] = 6] = "Color7";
    LabelColor[LabelColor["Color8"] = 7] = "Color8";
    LabelColor[LabelColor["Color9"] = 8] = "Color9";
    LabelColor[LabelColor["Color10"] = 9] = "Color10";
    LabelColor[LabelColor["Color11"] = 10] = "Color11";
    LabelColor[LabelColor["Color12"] = 11] = "Color12";
    LabelColor[LabelColor["Color13"] = 12] = "Color13";
    LabelColor[LabelColor["Color14"] = 13] = "Color14";
    LabelColor[LabelColor["Color15"] = 14] = "Color15";
    LabelColor[LabelColor["Color16"] = 15] = "Color16";
    LabelColor[LabelColor["Color17"] = 16] = "Color17";
    LabelColor[LabelColor["Color18"] = 17] = "Color18";
    LabelColor[LabelColor["Color19"] = 18] = "Color19";
    LabelColor[LabelColor["Color20"] = 19] = "Color20";
})(LabelColor || (exports.LabelColor = LabelColor = {}));
