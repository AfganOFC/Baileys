"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ALL_WA_PATCH_NAMES = void 0;
exports.ALL_WA_PATCH_NAMES = ['critical_block', 'critical_unblock_low', 'regular_high', 'regular_low', 'regular'];
