"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelAssociationType = void 0;
/** Association type */
var LabelAssociationType;
(function (LabelAssociationType) {
    LabelAssociationType["Chat"] = "label_jid";
    LabelAssociationType["Message"] = "label_message";
})(LabelAssociationType || (exports.LabelAssociationType = LabelAssociationType = {}));
